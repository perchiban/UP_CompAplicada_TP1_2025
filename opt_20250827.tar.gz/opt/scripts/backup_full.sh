#!/bin/bash

# Función de ayuda
show_help() {
    echo -e "=== BACKUP SCRIPT - AYUDA ==="
    echo ""
    echo -e "DESCRIPCIÓN:"
    echo "  Este script permite hacer backup de archivos de un directorio origen a un directorio destino"
    echo "  , creando archivos comprimidos tar.gz con fecha actual."
    echo ""
    echo -e "USO:"
    echo "  $0 [ORIGEN] [DESTINO]"
    echo "  $0 -help"
    echo ""
    echo -e "PARÁMETROS:"
    echo "  ORIGEN    - Directorio o archivo de origen"
    echo "  DESTINO   - Directorio de destino donde se guardará el backup"
    echo "  -help     - Muestra esta ayuda"
    echo ""
    echo -e "CARACTERÍSTICAS:"
    echo "  • Verifica que existan los archivos de origen y directorio de destino"
    echo "  • Crea archivos comprimidos tar.gz con formato: nombre_AAAAMMDD.tar.gz"
    echo ""
    echo -e "EJEMPLOS:"
    echo "  $0 /home/user/docs /backup/documentos"
    echo "  $0 archivo.txt /backup"
    echo ""
}

# Verificar si se pide ayuda
if [[ "$1" == "-help" ]]; then
    show_help
    exit 0
fi

# Verificar número de argumentos
if [[ $# -ne 2 ]]; then
    echo -e "Error: Argumentos incorrectos"
    echo "Usa '$0 -help' para ver la ayuda"
    exit 1
fi

# Asignar variables
ORIGEN="$1"
DESTINO="$2"

# Función para generar timestamp
get_timestamp() {
    date +"%Y%m%d"
}

# Verificar que existe el origen
if [[ ! -e "$ORIGEN" ]]; then
    echo -e "Error: El archivo o directorio origen '$ORIGEN' no existe"
    exit 1
fi

# Función principal de backup
realizar_backup() {
        local nombre_directorio=$(basename "$ORIGEN")
        local timestamp=$(get_timestamp)
        local nuevo_nombre="${nombre_directorio}_${timestamp}.tar.gz"
        local destino_completo="$DESTINO/$nuevo_nombre"
        
        echo -e "Se ha creado un archivo comprimido con todo el directorio: $nuevo_nombre"
        echo ""
        
            # Cambiar al directorio padre del origen
            local directorio_padre=$(dirname "$ORIGEN")
            local nombre_dir=$(basename "$ORIGEN")
            
            pushd "$directorio_padre" > /dev/null 2>&1
            
            # Crear archivo tar.gz del directorio completo
            tar -czf "$destino_completo" "$nombre_dir"
            local tar_result=$?
            
            popd > /dev/null 2>&1
            
}

# Realizar el backup
realizar_backup
